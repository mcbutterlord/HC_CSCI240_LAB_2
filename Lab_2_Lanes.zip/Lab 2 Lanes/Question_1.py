userName = input("Enter your name: ")
print("Hello",userName)