fTemp = float(input("Enter Fahrenheit temperature: "))
cTemp = ((fTemp-32)*(5/9))
print("Converted to Celsius:",(cTemp))